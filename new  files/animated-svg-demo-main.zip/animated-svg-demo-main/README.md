# Animated SVG Tutorial

Watch the full [SVG Animation Tutorial](https://youtu.be/UTHgr6NLeEw) on YouTube

## Usage

`git clone` then open the HTML pages in a browser 