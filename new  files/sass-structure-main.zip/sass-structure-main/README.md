# SASS Folder Structure
This is folder structure to organizing project files.

# How to use it ?
### write in your terminal :

> ```git clone https://github.com/AmrKhaleds/sass-structure.git```
- and start your project 🥰
